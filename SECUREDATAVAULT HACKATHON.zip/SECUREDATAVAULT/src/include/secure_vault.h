#ifndef SECURE_VAULT_H
#define SECURE_VAULT_H

int authenticate(char* password);
void storeData();
void retrieveData();
void deleteData();
void encryptData(const char* plaintext, unsigned char* ciphertext, int* ciphertext_len);
void decryptData(const unsigned char* ciphertext, int ciphertext_len, char* plaintext);

#endif