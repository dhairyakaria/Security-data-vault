#include "secure_vault.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/aes.h>

#define VAULT_PASSWORD "hackathon_secure"
#define DATA_FILE "vault.dat"
#define AES_KEY_SIZE 32  // 256-bit key
#define AES_BLOCK_SIZE 16

// Key for encryption and IV (Initialization Vector)
unsigned char key[AES_KEY_SIZE] = "hackathon_key_32_bytes_key_length!";
unsigned char iv[AES_BLOCK_SIZE] = "hackathon_iv_16";

// Authenticate user with a password
int authenticate(char* password) {
    if (strcmp(password, VAULT_PASSWORD) == 0) {
        return 1;
    }
    return 0;
}

// AES encryption function
void encryptData(const char* plaintext, unsigned char* ciphertext, int* ciphertext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);

    int len;
    EVP_EncryptUpdate(ctx, ciphertext, &len, (unsigned char *)plaintext, strlen(plaintext));
    *ciphertext_len = len;

    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    *ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

// AES decryption function
void decryptData(const unsigned char* ciphertext, int ciphertext_len, char* plaintext) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);

    int len;
    EVP_DecryptUpdate(ctx, (unsigned char *)plaintext, &len, ciphertext, ciphertext_len);
    int plaintext_len = len;

    EVP_DecryptFinal_ex(ctx, (unsigned char *)plaintext + len, &len);
    plaintext_len += len;

    plaintext[plaintext_len] = '\0'; // Null-terminate the decrypted plaintext

    EVP_CIPHER_CTX_free(ctx);
}

// Store data securely (AES encryption)
void storeData() {
    char data[1024];
    unsigned char encrypted_data[1024];
    int encrypted_len;
    FILE *fp;

    printf("Enter data to store: ");
    scanf("%s", data);

    // Encrypt the data
    encryptData(data, encrypted_data, &encrypted_len);

    // Write encrypted data to file
    fp = fopen(DATA_FILE, "wb");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return;
    }
    fwrite(encrypted_data, sizeof(unsigned char), encrypted_len, fp);
    fclose(fp);

    printf("Data stored securely!\n");
}

// Retrieve data from the vault (AES decryption)
void retrieveData() {
    unsigned char encrypted_data[1024];
    char decrypted_data[1024];
    FILE *fp;
    int encrypted_len;

    fp = fopen(DATA_FILE, "rb");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return;
    }

    encrypted_len = fread(encrypted_data, sizeof(unsigned char), 1024, fp);
    fclose(fp);

    // Decrypt the data
    decryptData(encrypted_data, encrypted_len, decrypted_data);

    printf("Data retrieved: %s\n", decrypted_data);
}

// Delete data securely (overwrite and delete file)
void deleteData() {
    FILE *fp;
    char data[1024];

    memset(data, 0, sizeof(data)); // Overwrite data

    fp = fopen(DATA_FILE, "wb");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return;
    }

    fwrite(data, sizeof(char), 1024, fp); // Write zeros to file
    fclose(fp);

    printf("Data deleted securely!\n");
}