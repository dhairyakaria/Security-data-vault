#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include "secure_vault.h"

int main() {
    int choice;
    char password[100];

    printf("Welcome to Secure Data Vault\n");
    printf("Please enter your password to access the vault: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = 0; // Remove newline character

    if (authenticate(password)) {
        printf("\nAccess granted!\n");

        while (1) {
            printf("\n1. Store Data\n2. Retrieve Data\n3. Delete Data\n4. Exit\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch(choice) {
                case 1:
                    storeData();
                    break;
                case 2:
                    retrieveData();
                    break;
                case 3:
                    deleteData();
                    break;
                case 4:
                    exit(0);
                    break;
                default:
                    printf("Invalid choice, try again.\n");
            }
        }
    } else {
        printf("\nAccess denied!\n");
    }
    return 0;
}